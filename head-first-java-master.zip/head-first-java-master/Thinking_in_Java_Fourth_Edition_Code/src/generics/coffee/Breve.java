//: generics/coffee/Breve.java
package generics.coffee;
public class Breve extends Coffee {} ///:~
