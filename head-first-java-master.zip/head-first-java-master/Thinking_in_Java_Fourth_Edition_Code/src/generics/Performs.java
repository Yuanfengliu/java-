//: generics/Performs.java

public interface Performs {
  void speak();
  void sit();
} ///:~
